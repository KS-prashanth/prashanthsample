import React from "react";

const Excersise5 = () => {
    return (
        <div>
        <h1>Excersise 5</h1>
        </div>
    );
    };

export default Excersise5;