import {createSlice} from '@reduxjs/toolkit';

const initialTodos = [
    { id: 1, do: 'Learn React', done: true },
    { id: 2, do: 'Learn Redux', done: false, color: 'purple' },
    { id: 3, do: 'Build something fun!', done: false, color: 'blue' }
];

const todosSlice = createSlice({
    name: 'todos',
    initialState: initialTodos,
});

export default todosSlice.reducer;
