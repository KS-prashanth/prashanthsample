import React from "react";
import ReduxExamples from "./redux-examples";

const Excersise6 = () => {
    return (
        <div>
        <h1>Excersise 6</h1>
        <ReduxExamples/>
        </div>
    );
    };

export default Excersise6;